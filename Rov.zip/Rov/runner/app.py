from flask import Flask, render_template, Response, request, jsonify
import cv2
import threading
import numpy as np

app = Flask(__name__)

# Global variables for camera and video streaming
cap = None
video_stream_thread = None
frame = None
run_video_stream = False
run_detection = False
green_detection_thread = None

# Known width of the target green object in centimeters
KNOWN_WIDTH = 10  # Adjust this value based on your target object's actual width
FOCAL_LENGTH = 615  # This value should be calibrated based on your camera setup

def start_video_stream():
    global cap, frame, run_video_stream, run_detection

    cap = cv2.VideoCapture("http://192.168.81.177:2020/video")

    while run_video_stream:
        ret, frame = cap.read()
        if not ret:
            break

        # Perform green object detection if enabled
        if run_detection:
            frame, direction, distance = detect_green_objects(frame)

        # Draw the crosshair
        height, width, _ = frame.shape
        center_x, center_y = width // 2, height // 2
        cv2.line(frame, (center_x, 0), (center_x, height), (255, 0, 0), 1)  # Vertical line
        cv2.line(frame, (0, center_y), (width, center_y), (255, 0, 0), 1)  # Horizontal line

        # Convert the frame to JPEG format
        ret, buffer = cv2.imencode('.jpg', frame)
        frame_bytes = buffer.tobytes()

        # Yield the frame in byte format
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

    cap.release()

def detect_green_objects(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_green = np.array([35, 100, 100])
    upper_green = np.array([85, 255, 255])
    mask = cv2.inRange(hsv, lower_green, upper_green)
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    direction = "STOP"
    distance = None

    # Reset terminal output to "STOP" if no object is detected
    if not contours:
        print("stop")
        return frame, direction, distance

    # If there are contours, process each one
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > 500:  # Adjust the area threshold as needed
            x, y, w, h = cv2.boundingRect(contour)
            distance = calculate_distance(KNOWN_WIDTH, FOCAL_LENGTH, w)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            object_center_x = x + w // 2
            frame_center_x = frame.shape[1] // 2

            # Determine direction based on object position
            if object_center_x < frame_center_x - (frame_center_x * 0.2):
                direction = "LEFT"
                print("move left")
            elif object_center_x > frame_center_x + (frame_center_x * 0.2):
                direction = "RIGHT"
                print("move right")
            else:
                direction = "CENTER"
                print("-")

            # Print the distance measurement
            # print(f"Distance: {distance:.2f} cm")

            # Put the distance text on the frame
            cv2.putText(frame, f"{distance:.2f} cm", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

            # Check if the object is centered and within the desired distance range
            if direction == "CENTER":
                if 38 <= distance <= 40:
                    print("PICK OBJECT")
                elif distance < 38:
                    print("move backward")
                elif distance > 40:
                    print("move forward")

            break  # Only process the first detected object

    return frame, direction, distance

def calculate_distance(known_width, focal_length, perceived_width):
    return (known_width * focal_length) / perceived_width

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    global video_stream_thread, run_video_stream

    if video_stream_thread is None or not video_stream_thread.is_alive():
        run_video_stream = True
        video_stream_thread = threading.Thread(target=start_video_stream)
        video_stream_thread.start()

    return Response(start_video_stream(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/button-action', methods=['POST'])
def button_action():
    global run_detection, green_detection_thread

    action = request.json.get('action')
    if action == 'AUTO':
        if green_detection_thread is None or not green_detection_thread.is_alive():
            run_detection = True
            green_detection_thread = threading.Thread(target=detect_green_objects_thread)
            green_detection_thread.start()
            return jsonify(success=True)
        else:
            return jsonify(success=False, message="Detection already running."), 400
    elif action == 'STOP':
        run_detection = False
        return jsonify(success=True)
    elif action == 'MANUAL':
        run_detection = False  # Stop green detection if it's running
        if green_detection_thread and green_detection_thread.is_alive():
            green_detection_thread.join()  # Wait for the thread to finish
        return jsonify(success=True)

    return jsonify(success=False, message="Invalid action."), 400

def detect_green_objects_thread():
    global frame, run_detection

    while run_detection:
        if frame is not None:
            frame, direction, distance = detect_green_objects(frame)
            # Here you can send the direction to the rover if needed
            # send_direction_to_rover(direction)

if __name__ == '__main__':
    app.run(debug=True)
