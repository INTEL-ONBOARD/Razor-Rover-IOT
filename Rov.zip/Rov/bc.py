from flask import Flask, render_template, Response, request, jsonify
import cv2
import threading
import numpy as np
import RPi.GPIO as GPIO
from Adafruit_SSD1306 import SSD1306_128_64
from PIL import Image, ImageDraw, ImageFont

app = Flask(__name__)

# Global variables for camera and video streaming
cap = None
video_stream_thread = None
frame = None
run_video_stream = False
run_detection = False
green_detection_thread = None

# GPIO setup
GPIO.setmode(GPIO.BCM)
GPIO.setup(19, GPIO.OUT)  # Manual
GPIO.setup(20, GPIO.OUT)  # PICK
GPIO.setup(21, GPIO.OUT)  # DROP
GPIO.setup(22, GPIO.OUT)  # STOP
GPIO.setup(23, GPIO.OUT)  # RIGHT
GPIO.setup(24, GPIO.OUT)  # LEFT
GPIO.setup(25, GPIO.OUT)  # FORWARD
GPIO.setup(26, GPIO.OUT)  # AUTO

def reset_gpio():
    GPIO.output(19, GPIO.LOW)  # Manual
    GPIO.output(20, GPIO.LOW)  # PICK
    GPIO.output(21, GPIO.LOW)  # DROP
    GPIO.output(22, GPIO.LOW)  # STOP
    GPIO.output(23, GPIO.LOW)  # RIGHT
    GPIO.output(24, GPIO.LOW)  # LEFT
    GPIO.output(25, GPIO.LOW)  # FORWARD
    GPIO.output(26, GPIO.LOW)  # AUTO

# OLED display setup
disp = SSD1306_128_64(rst=None)
disp.begin()
disp.clear()
disp.display()

width = disp.width
height = disp.height
image = Image.new('1', (width, height))
draw = ImageDraw.Draw(image)
font = ImageFont.load_default()

def update_oled_display(arm_status, rover_status):
    draw.rectangle((0, 0, width, height), outline=0, fill=0)
    draw.text((0, 0), f'Arm Status: {arm_status}', font=font, fill=255)
    draw.text((0, 20), f'Rover Status: {rover_status}', font=font, fill=255)
    disp.image(image)
    disp.display()

# Known width of the target green object in centimeters
KNOWN_WIDTH = 10  # Adjust this value based on your target object's actual width
FOCAL_LENGTH = 615  # This value should be calibrated based on your camera setup

def start_video_stream():
    global cap, frame, run_video_stream, run_detection

    cap = cv2.VideoCapture("http://192.168.76.177:2020/video")

    while run_video_stream:
        ret, frame = cap.read()
        if not ret:
            break

        # Perform green object detection if enabled
        if run_detection:
            frame, direction, distance = detect_green_objects(frame)

        # Draw the crosshair
        height, width, _ = frame.shape
        center_x, center_y = width // 2, height // 2
        cv2.line(frame, (center_x, 0), (center_x, height), (255, 0, 0), 1)  # Vertical line
        cv2.line(frame, (0, center_y), (width, center_y), (255, 0, 0), 1)  # Horizontal line

        # Convert the frame to JPEG format
        ret, buffer = cv2.imencode('.jpg', frame)
        frame_bytes = buffer.tobytes()

        # Yield the frame in byte format
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame_bytes + b'\r\n')

    cap.release()

def detect_green_objects(frame):
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_green = np.array([35, 100, 100])
    upper_green = np.array([85, 255, 255])
    mask = cv2.inRange(hsv, lower_green, upper_green)
    contours, _ = cv2.findContours(mask, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    direction = "STOP"
    distance = None

    # Reset terminal output to "STOP" if no object is detected
    if not contours:
        print("stop")
        update_oled_display("STOP", "STOP")
        return frame, direction, distance

    # If there are contours, process each one
    for contour in contours:
        area = cv2.contourArea(contour)
        if area > 500:  # Adjust the area threshold as needed
            x, y, w, h = cv2.boundingRect(contour)
            distance = calculate_distance(KNOWN_WIDTH, FOCAL_LENGTH, w)
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            object_center_x = x + w // 2
            frame_center_x = frame.shape[1] // 2

            # Determine direction based on object position
            if object_center_x < frame_center_x - (frame_center_x * 0.2):
                direction = "LEFT"
                print("move left")
            elif object_center_x > frame_center_x + (frame_center_x * 0.2):
                direction = "RIGHT"
                print("move right")
            else:
                direction = "CENTER"
                print("-")

            # Put the distance text on the frame
            cv2.putText(frame, f"{distance:.2f} cm", (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

            # Check if the object is centered and within the desired distance range
            if direction == "CENTER":
                if 38 <= distance <= 40:
                    print("PICK OBJECT")
                    update_oled_display("PICK", "CENTER")
                elif distance < 38:
                    print("move backward")
                    update_oled_display("MOVE BACKWARD", "CENTER")
                elif distance > 40:
                    print("move forward")
                    update_oled_display("MOVE FORWARD", "CENTER")
            else:
                update_oled_display("STOP", direction)

            break  # Only process the first detected object

    return frame, direction, distance

def calculate_distance(known_width, focal_length, perceived_width):
    return (known_width * focal_length) / perceived_width

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    global video_stream_thread, run_video_stream

    if video_stream_thread is None or not video_stream_thread.is_alive():
        run_video_stream = True
        video_stream_thread = threading.Thread(target=start_video_stream)
        video_stream_thread.start()

    return Response(start_video_stream(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/button-action', methods=['POST'])
def button_action():
    global run_detection, green_detection_thread

    action = request.json.get('action')
    if action == 'AUTO':
        if green_detection_thread is None or not green_detection_thread.is_alive():
            run_detection = True
            green_detection_thread = threading.Thread(target=detect_green_objects_thread)
            green_detection_thread.start()
            GPIO.output(19, GPIO.LOW) # Set GPIO 19 LOW for AUTO
            update_oled_display("AUTO", "STOP")
            return jsonify(success=True)
        else:
            return jsonify(success=False, message="Detection already running."), 400
    elif action == 'STOP':
        run_detection = False
        reset_gpio()
        GPIO.output(22, GPIO.LOW)  # Set GPIO 22 LOW for STOP
        GPIO.output(23, GPIO.LOW)
        GPIO.output(24, GPIO.LOW)
        GPIO.output(25, GPIO.LOW)
        update_oled_display("STOP", "STOP")
        return jsonify(success=True)
    elif action == 'MANUAL':
        run_detection = False  # Stop green detection if it's running
        if green_detection_thread and green_detection_thread.is_alive():
            green_detection_thread.join()  # Wait for the thread to finish
        GPIO.output(19, GPIO.HIGH)  # Set GPIO 19 HIGH for MANUAL
        GPIO.output(26, GPIO.LOW)
        update_oled_display("MANUAL", "STOP")
        return jsonify(success=True)
    elif action == 'FORWARD':
        reset_gpio()
        GPIO.output(25, GPIO.HIGH)  # Set GPIO 25 HIGH for FORWARD
        GPIO.output(19, GPIO.HIGH)
        update_oled_display("MANUAL", "FORWARD")
        return jsonify(success=True)
    elif action == 'BACKWARD':
        reset_gpio()
        GPIO.output(22, GPIO.HIGH)  # Set GPIO 22 HIGH for STOP (backward could imply stop in your context)
        GPIO.output(19, GPIO.HIGH)
        update_oled_display("MANUAL", "BACKWARD")
        return jsonify(success=True)
    elif action == 'LEFT':
        reset_gpio()
        GPIO.output(24, GPIO.HIGH)  # Set GPIO 24 HIGH for LEFT
        GPIO.output(19, GPIO.HIGH)
        update_oled_display("MANUAL", "LEFT")
        return jsonify(success=True)
    elif action == 'RIGHT':
        reset_gpio()
        GPIO.output(23, GPIO.HIGH)  # Set GPIO 23 HIGH for RIGHT
        GPIO.output(19, GPIO.HIGH)
        update_oled_display("MANUAL", "RIGHT")
        return jsonify(success=True)
    elif action == 'PICK':
        reset_gpio()
        GPIO.output(20, GPIO.HIGH)  # Set GPIO 20 HIGH for PICK
        GPIO.output(21, GPIO.LOW)
        GPIO.output(26, GPIO.LOW)
        update_oled_display("PICK", "STOP")
        return jsonify(success=True)
    elif action == 'DROP':
        reset_gpio()
        GPIO.output(21, GPIO.HIGH)  # Set GPIO 21 HIGH for DROP
        GPIO.output(20, GPIO.LOW)
        GPIO.output(26, GPIO.LOW)
        update_oled_display("DROP", "STOP")
        return jsonify(success=True)
    elif action == 'OC':
        reset_gpio()
        GPIO.output(26, GPIO.HIGH)  # Set GPIO 26 HIGH for OC
        GPIO.output(21, GPIO.LOW)
        GPIO.output(20, GPIO.LOW)
        update_oled_display("OC", "STOP")
        return jsonify(success=True)

    return jsonify(success=False, message="Invalid action."), 400

def detect_green_objects_thread():
    global frame, run_detection

    while run_detection:
        if frame is not None:
            detect_green_objects(frame)

if __name__ == '__main__':
    try:
        app.run(debug=True, host='0.0.0.0')
    finally:
        GPIO.cleanup()
